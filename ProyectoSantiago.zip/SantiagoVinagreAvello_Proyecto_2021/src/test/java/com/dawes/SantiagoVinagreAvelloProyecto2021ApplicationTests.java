package com.dawes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SantiagoVinagreAvelloProyecto2021ApplicationTests {

	@Test
	void contextLoads() {
	}

}
