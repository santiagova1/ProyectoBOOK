package com.dawes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SantiagoVinagreAvelloProyecto2021Application {

	public static void main(String[] args) {
		SpringApplication.run(SantiagoVinagreAvelloProyecto2021Application.class, args);
	}

}
