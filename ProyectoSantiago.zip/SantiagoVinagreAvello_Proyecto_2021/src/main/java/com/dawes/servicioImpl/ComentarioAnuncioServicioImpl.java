package com.dawes.servicioImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dawes.modelo.ComentarioAnuncioVO;
import com.dawes.repositorio.ComentarioAnuncioRepositorio;
import com.dawes.servicio.ComentarioAnuncioServicio;

@Service
public class ComentarioAnuncioServicioImpl implements ComentarioAnuncioServicio {
	

	@Autowired
	private ComentarioAnuncioRepositorio car;

	@Override
	public <S extends ComentarioAnuncioVO> S save(S entity) {
		return car.save(entity);
	}

	@Override
	public <S extends ComentarioAnuncioVO> Iterable<S> saveAll(Iterable<S> entities) {
		return car.saveAll(entities);
	}

	@Override
	public Optional<ComentarioAnuncioVO> findById(Integer id) {
		return car.findById(id);
	}

	@Override
	public boolean existsById(Integer id) {
		return car.existsById(id);
	}

	@Override
	public Iterable<ComentarioAnuncioVO> findAll() {
		return car.findAll();
	}

	@Override
	public Iterable<ComentarioAnuncioVO> findAllById(Iterable<Integer> ids) {
		return car.findAllById(ids);
	}

	@Override
	public long count() {
		return car.count();
	}

	@Override
	public void deleteById(Integer id) {
		car.deleteById(id);
	}

	@Override
	public void delete(ComentarioAnuncioVO entity) {
		car.delete(entity);
	}

	@Override
	public void deleteAllById(Iterable<? extends Integer> ids) {
		car.deleteAllById(ids);
	}

	@Override
	public void deleteAll(Iterable<? extends ComentarioAnuncioVO> entities) {
		car.deleteAll(entities);
	}

	@Override
	public void deleteAll() {
		car.deleteAll();
	}
	
	
}
