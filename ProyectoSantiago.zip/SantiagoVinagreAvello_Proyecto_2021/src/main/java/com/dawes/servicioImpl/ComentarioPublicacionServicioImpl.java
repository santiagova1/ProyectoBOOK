package com.dawes.servicioImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dawes.modelo.ComentarioPublicacionVO;
import com.dawes.repositorio.ComentarioPublicacionRepositorio;
import com.dawes.servicio.ComentarioPublicacionServicio;

@Service
public class ComentarioPublicacionServicioImpl implements ComentarioPublicacionServicio {

	@Autowired
	private ComentarioPublicacionRepositorio cpr;

	@Override
	public <S extends ComentarioPublicacionVO> S save(S entity) {
		return cpr.save(entity);
	}

	@Override
	public <S extends ComentarioPublicacionVO> Iterable<S> saveAll(Iterable<S> entities) {
		return cpr.saveAll(entities);
	}

	@Override
	public Optional<ComentarioPublicacionVO> findById(Integer id) {
		return cpr.findById(id);
	}

	@Override
	public boolean existsById(Integer id) {
		return cpr.existsById(id);
	}

	@Override
	public Iterable<ComentarioPublicacionVO> findAll() {
		return cpr.findAll();
	}

	@Override
	public Iterable<ComentarioPublicacionVO> findAllById(Iterable<Integer> ids) {
		return cpr.findAllById(ids);
	}

	@Override
	public long count() {
		return cpr.count();
	}

	@Override
	public void deleteById(Integer id) {
		cpr.deleteById(id);
	}

	@Override
	public void delete(ComentarioPublicacionVO entity) {
		cpr.delete(entity);
	}

	@Override
	public void deleteAllById(Iterable<? extends Integer> ids) {
		cpr.deleteAllById(ids);
	}

	@Override
	public void deleteAll(Iterable<? extends ComentarioPublicacionVO> entities) {
		cpr.deleteAll(entities);
	}

	@Override
	public void deleteAll() {
		cpr.deleteAll();
	}
	
	
	
	
}
