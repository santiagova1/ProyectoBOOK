package com.dawes.servicio;

import java.util.Optional;

import com.dawes.modelo.ComentarioAnuncioVO;

public interface ComentarioAnuncioServicio {

	<S extends ComentarioAnuncioVO> S save(S entity);

	<S extends ComentarioAnuncioVO> Iterable<S> saveAll(Iterable<S> entities);

	Optional<ComentarioAnuncioVO> findById(Integer id);

	boolean existsById(Integer id);

	Iterable<ComentarioAnuncioVO> findAll();

	Iterable<ComentarioAnuncioVO> findAllById(Iterable<Integer> ids);

	long count();

	void deleteById(Integer id);

	void delete(ComentarioAnuncioVO entity);

	void deleteAllById(Iterable<? extends Integer> ids);

	void deleteAll(Iterable<? extends ComentarioAnuncioVO> entities);

	void deleteAll();

}