package com.dawes.servicio;

import java.util.Optional;

import com.dawes.modelo.ComentarioPublicacionVO;

public interface ComentarioPublicacionServicio {

	<S extends ComentarioPublicacionVO> S save(S entity);

	<S extends ComentarioPublicacionVO> Iterable<S> saveAll(Iterable<S> entities);

	Optional<ComentarioPublicacionVO> findById(Integer id);

	boolean existsById(Integer id);

	Iterable<ComentarioPublicacionVO> findAll();

	Iterable<ComentarioPublicacionVO> findAllById(Iterable<Integer> ids);

	long count();

	void deleteById(Integer id);

	void delete(ComentarioPublicacionVO entity);

	void deleteAllById(Iterable<? extends Integer> ids);

	void deleteAll(Iterable<? extends ComentarioPublicacionVO> entities);

	void deleteAll();

}