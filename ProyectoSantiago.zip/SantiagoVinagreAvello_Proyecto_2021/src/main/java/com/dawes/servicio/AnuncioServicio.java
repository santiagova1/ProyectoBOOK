package com.dawes.servicio;

import java.util.Optional;

import com.dawes.modelo.AnuncioVO;

public interface AnuncioServicio {

	<S extends AnuncioVO> S save(S entity);

	<S extends AnuncioVO> Iterable<S> saveAll(Iterable<S> entities);

	Optional<AnuncioVO> findById(Integer id);

	boolean existsById(Integer id);

	Iterable<AnuncioVO> findAll();

	Iterable<AnuncioVO> findAllById(Iterable<Integer> ids);

	long count();

	void deleteById(Integer id);

	void delete(AnuncioVO entity);

	void deleteAllById(Iterable<? extends Integer> ids);

	void deleteAll(Iterable<? extends AnuncioVO> entities);

	void deleteAll();

}