package com.dawes.seguridad;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.dawes.servicioImpl.UsuarioServicioImpl;


@Configuration
@EnableWebSecurity
public class Seguridad extends WebSecurityConfigurerAdapter {
	 
	
	
		@Autowired
		UsuarioServicioImpl userDetailsService;

	
	//Encriptación
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	//Encriptación de la contraseña
	public String encriptar(String contrasenia) {
		return passwordEncoder().encode(contrasenia);
	}
	
	//Autenficicamos
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(userDetailsService);
	}
	
	
	//Configuramos los roles
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests().antMatchers("/usuarioAdministrador/**").hasRole("ADMIN");
		http.authorizeRequests().antMatchers("/usuarioRegistrado/**").hasAnyRole("USER", "ADMIN");
		http.formLogin().loginPage("/login");										
		//http.exceptionHandling().accessDeniedPage("/403");							
		http.logout().logoutSuccessUrl("/login?logout");							//URL desconexión.
		http.csrf().disable();
	}
	
	
}