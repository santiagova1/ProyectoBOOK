package com.dawes.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.dawes.modelo.RolVO;
import com.dawes.modelo.UsuarioRolVO;
import com.dawes.modelo.UsuarioVO;
import com.dawes.servicio.RolServicio;
import com.dawes.servicio.UsuarioRolServicio;
import com.dawes.servicio.UsuarioServicio;



@Controller
public class Registro {

	@Autowired
	private RolServicio rs;

	@Autowired
	private UsuarioServicio us;
	
	


	@Autowired
	private UsuarioRolServicio urs;
	
	
	@GetMapping("/index")
	public String index() {
		return "index";
	}
	
	
	//Iniciar sesión
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	//Registro
	@GetMapping("/signup")
	public String signup(Model modelo, UsuarioVO user) {
	    modelo.addAttribute("usuarioNuevo", new UsuarioVO());
		return "signup";
	}
	
	
	@PostMapping("/submit")
	public String submit(@ModelAttribute UsuarioVO user, Model modelo) {
		
		user.setPassword(encriptar(user.getContrasenia()));
		user.setUsername(user.getNombreusuario());
	       us.save(user);
	       
	        RolVO rolseleccionado = rs.findById(2).get();
	        UsuarioRolVO usuariorol = new UsuarioRolVO(0,user,rolseleccionado);
	        urs.save(usuariorol);
	        modelo.addAttribute("usuario", user); 
	        modelo.addAttribute("usuarioroles", urs.findAll());
	        return "index";
	};

	
	@Bean
	public BCryptPasswordEncoder passwordEncode() {
		return new BCryptPasswordEncoder();
	}
	
	public String encriptar(String contrasenia) {
		return passwordEncode().encode(contrasenia);
	}
	
	
	
	
	@GetMapping("/logout")
	public String logout() {
		return "login";
	}
	
	
}
