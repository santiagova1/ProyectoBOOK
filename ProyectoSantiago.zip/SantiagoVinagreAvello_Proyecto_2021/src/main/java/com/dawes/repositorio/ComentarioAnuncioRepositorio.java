package com.dawes.repositorio;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dawes.modelo.ComentarioAnuncioVO;

@Repository	
public interface ComentarioAnuncioRepositorio extends CrudRepository<ComentarioAnuncioVO, Integer> {

}
