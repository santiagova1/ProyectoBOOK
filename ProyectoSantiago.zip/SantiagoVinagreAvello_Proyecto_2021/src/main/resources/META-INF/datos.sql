INSERT INTO `roles` (`idrol`,`nombrerol`) VALUES (1,'ROLE_USER');
INSERT INTO `roles` (`idrol`,`nombrerol`) VALUES (2,'ROLE_ADMIN');

INSERT INTO `anuncios` (`idanuncio`,`descripcion`,`fechacreacion`,`precio`,`telefono`,`titulo`,`ubicacion`,`idusuario`) VALUES (1,'3ra edición de bolsillo de la que me quiero deshacer, un poco roto el lomo.','2021-03-09',,12.00,123456789,`Se vende "La Comunidad del Anillo"`,1);
INSERT INTO `publicaciones` (`idpublicacion`,`contenido`,`fechacreacion`,`titulo`,`idusuario`) VALUES (2,'Gente del Foro, ¿Estáis a favor o en contra?','2021-03-09','Adaptaciones cinematográficas de libros. ¿Opiniones?',1);
